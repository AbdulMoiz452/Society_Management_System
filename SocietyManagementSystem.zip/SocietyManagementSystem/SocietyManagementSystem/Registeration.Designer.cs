﻿namespace SocietyManagementSystem
{
    partial class Registeration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registeration));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Gender_ComboBox = new System.Windows.Forms.ComboBox();
            this.Phone_textbox = new System.Windows.Forms.TextBox();
            this.Phone = new System.Windows.Forms.Label();
            this.Register_button = new System.Windows.Forms.Button();
            this.Password_textbox = new System.Windows.Forms.TextBox();
            this.Username_textbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Designation_comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Email_label = new System.Windows.Forms.Label();
            this.Email_textbox = new System.Windows.Forms.TextBox();
            this.Address_textbox = new System.Windows.Forms.TextBox();
            this.LName_textbox = new System.Windows.Forms.TextBox();
            this.FName_textbox = new System.Windows.Forms.TextBox();
            this.Address_label = new System.Windows.Forms.Label();
            this.LName_label = new System.Windows.Forms.Label();
            this.FName = new System.Windows.Forms.Label();
            this.LogIn_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(695, 89);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(347, 327);
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            // 
            // Gender_ComboBox
            // 
            this.Gender_ComboBox.FormattingEnabled = true;
            this.Gender_ComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.Gender_ComboBox.Location = new System.Drawing.Point(473, 177);
            this.Gender_ComboBox.Name = "Gender_ComboBox";
            this.Gender_ComboBox.Size = new System.Drawing.Size(161, 21);
            this.Gender_ComboBox.TabIndex = 42;
            // 
            // Phone_textbox
            // 
            this.Phone_textbox.Location = new System.Drawing.Point(473, 247);
            this.Phone_textbox.Name = "Phone_textbox";
            this.Phone_textbox.Size = new System.Drawing.Size(161, 20);
            this.Phone_textbox.TabIndex = 41;
            // 
            // Phone
            // 
            this.Phone.AutoSize = true;
            this.Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Phone.Location = new System.Drawing.Point(364, 247);
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(54, 17);
            this.Phone.TabIndex = 40;
            this.Phone.Text = "Phone";
            // 
            // Register_button
            // 
            this.Register_button.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Register_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Register_button.Location = new System.Drawing.Point(72, 392);
            this.Register_button.Margin = new System.Windows.Forms.Padding(0);
            this.Register_button.Name = "Register_button";
            this.Register_button.Size = new System.Drawing.Size(227, 46);
            this.Register_button.TabIndex = 39;
            this.Register_button.Text = "Register";
            this.Register_button.UseVisualStyleBackColor = false;
            this.Register_button.Click += new System.EventHandler(this.Register_button_Click);
            // 
            // Password_textbox
            // 
            this.Password_textbox.Location = new System.Drawing.Point(473, 306);
            this.Password_textbox.Name = "Password_textbox";
            this.Password_textbox.PasswordChar = '*';
            this.Password_textbox.Size = new System.Drawing.Size(161, 20);
            this.Password_textbox.TabIndex = 38;
            // 
            // Username_textbox
            // 
            this.Username_textbox.Location = new System.Drawing.Point(152, 308);
            this.Username_textbox.Name = "Username_textbox";
            this.Username_textbox.Size = new System.Drawing.Size(147, 20);
            this.Username_textbox.TabIndex = 37;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(364, 308);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 17);
            this.label4.TabIndex = 36;
            this.label4.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 311);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 17);
            this.label3.TabIndex = 35;
            this.label3.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 247);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 17);
            this.label2.TabIndex = 34;
            this.label2.Text = "Designation";
            // 
            // Designation_comboBox1
            // 
            this.Designation_comboBox1.FormattingEnabled = true;
            this.Designation_comboBox1.Items.AddRange(new object[] {
            "Administrator",
            "SocietyLead",
            "SocietyMember"});
            this.Designation_comboBox1.Location = new System.Drawing.Point(152, 243);
            this.Designation_comboBox1.Name = "Designation_comboBox1";
            this.Designation_comboBox1.Size = new System.Drawing.Size(147, 21);
            this.Designation_comboBox1.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(364, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 17);
            this.label1.TabIndex = 32;
            this.label1.Text = "Gender";
            // 
            // Email_label
            // 
            this.Email_label.AutoSize = true;
            this.Email_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email_label.Location = new System.Drawing.Point(364, 119);
            this.Email_label.Name = "Email_label";
            this.Email_label.Size = new System.Drawing.Size(47, 17);
            this.Email_label.TabIndex = 31;
            this.Email_label.Text = "Email";
            // 
            // Email_textbox
            // 
            this.Email_textbox.Location = new System.Drawing.Point(473, 119);
            this.Email_textbox.Name = "Email_textbox";
            this.Email_textbox.Size = new System.Drawing.Size(161, 20);
            this.Email_textbox.TabIndex = 30;
            // 
            // Address_textbox
            // 
            this.Address_textbox.Location = new System.Drawing.Point(137, 118);
            this.Address_textbox.Multiline = true;
            this.Address_textbox.Name = "Address_textbox";
            this.Address_textbox.Size = new System.Drawing.Size(153, 74);
            this.Address_textbox.TabIndex = 29;
            // 
            // LName_textbox
            // 
            this.LName_textbox.Location = new System.Drawing.Point(473, 63);
            this.LName_textbox.Name = "LName_textbox";
            this.LName_textbox.Size = new System.Drawing.Size(161, 20);
            this.LName_textbox.TabIndex = 28;
            // 
            // FName_textbox
            // 
            this.FName_textbox.Location = new System.Drawing.Point(137, 62);
            this.FName_textbox.Name = "FName_textbox";
            this.FName_textbox.Size = new System.Drawing.Size(153, 20);
            this.FName_textbox.TabIndex = 27;
            // 
            // Address_label
            // 
            this.Address_label.AutoSize = true;
            this.Address_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address_label.Location = new System.Drawing.Point(26, 118);
            this.Address_label.Name = "Address_label";
            this.Address_label.Size = new System.Drawing.Size(67, 17);
            this.Address_label.TabIndex = 26;
            this.Address_label.Text = "Address";
            // 
            // LName_label
            // 
            this.LName_label.AutoSize = true;
            this.LName_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LName_label.Location = new System.Drawing.Point(364, 63);
            this.LName_label.Name = "LName_label";
            this.LName_label.Size = new System.Drawing.Size(85, 17);
            this.LName_label.TabIndex = 25;
            this.LName_label.Text = "Last Name";
            // 
            // FName
            // 
            this.FName.AutoSize = true;
            this.FName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FName.Location = new System.Drawing.Point(26, 62);
            this.FName.Name = "FName";
            this.FName.Size = new System.Drawing.Size(86, 17);
            this.FName.TabIndex = 24;
            this.FName.Text = "First Name";
            // 
            // LogIn_button
            // 
            this.LogIn_button.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LogIn_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.LogIn_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogIn_button.Location = new System.Drawing.Point(405, 392);
            this.LogIn_button.Margin = new System.Windows.Forms.Padding(0);
            this.LogIn_button.Name = "LogIn_button";
            this.LogIn_button.Size = new System.Drawing.Size(229, 46);
            this.LogIn_button.TabIndex = 43;
            this.LogIn_button.Text = "LogIn";
            this.LogIn_button.UseVisualStyleBackColor = false;
            this.LogIn_button.Click += new System.EventHandler(this.LogIn_button_Click);
            // 
            // Registeration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 500);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.LogIn_button);
            this.Controls.Add(this.Gender_ComboBox);
            this.Controls.Add(this.Phone_textbox);
            this.Controls.Add(this.Phone);
            this.Controls.Add(this.Register_button);
            this.Controls.Add(this.Password_textbox);
            this.Controls.Add(this.Username_textbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Designation_comboBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Email_label);
            this.Controls.Add(this.Email_textbox);
            this.Controls.Add(this.Address_textbox);
            this.Controls.Add(this.LName_textbox);
            this.Controls.Add(this.FName_textbox);
            this.Controls.Add(this.Address_label);
            this.Controls.Add(this.LName_label);
            this.Controls.Add(this.FName);
            this.Name = "Registeration";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Registeration_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ComboBox Gender_ComboBox;
        private System.Windows.Forms.TextBox Phone_textbox;
        private System.Windows.Forms.Label Phone;
        private System.Windows.Forms.Button Register_button;
        private System.Windows.Forms.TextBox Password_textbox;
        private System.Windows.Forms.TextBox Username_textbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Designation_comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Email_label;
        private System.Windows.Forms.TextBox Email_textbox;
        private System.Windows.Forms.TextBox Address_textbox;
        private System.Windows.Forms.TextBox LName_textbox;
        private System.Windows.Forms.TextBox FName_textbox;
        private System.Windows.Forms.Label Address_label;
        private System.Windows.Forms.Label LName_label;
        private System.Windows.Forms.Label FName;
        private System.Windows.Forms.Button LogIn_button;
    }
}
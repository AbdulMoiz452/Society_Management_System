﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SocietyManagementSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Login_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection("Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True");

            string username, password;
            username = username_textbox2.Text;
            password = password_textbox2.Text;


            if (comboBox1.SelectedItem == "Administrator")
            {


                try
                {
                    string query = "SELECT * FROM administrator WHERE username = '" + username_textbox2.Text + "' AND password = '" + password_textbox2.Text + "'";


                    SqlDataAdapter sda = new SqlDataAdapter(query, con);

                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);

                    if (dtable.Rows.Count > 0)
                    {
                        string designation = dtable.Rows[0]["designation"].ToString();

                        username = username_textbox2.Text;
                        password = password_textbox2.Text;

                       
                        CurrentUser.Username = username_textbox2.Text; 

                        MessageBox.Show("Welcome Administrator");
                        AdmininstratorForm adminform = new AdmininstratorForm();
                        adminform.Show();
                        this.Hide();
                        

                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password.");
                        username_textbox2.Clear();
                        password_textbox2.Clear();
                        username_textbox2.Focus();

                    }



                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {


                }
            }

            else if (comboBox1.SelectedItem == "SocietyLead")
            {


                try
                {
                    string query = "SELECT * FROM SocietyLead WHERE username = '" + username_textbox2.Text + "' AND password = '" + password_textbox2.Text + "'";


                    SqlDataAdapter sda = new SqlDataAdapter(query, con);

                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);

                    if (dtable.Rows.Count > 0)
                    {
                        string designation = dtable.Rows[0]["designation"].ToString();

                        username = username_textbox2.Text;
                        password = password_textbox2.Text;

                      
                        CurrentUser.Username = username_textbox2.Text; 

                        
                        MessageBox.Show("Welcome Society Leader");
                        SocietyLeadForm societyform = new SocietyLeadForm();
                        societyform.Show();
                        this.Hide();
                      



                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password.");
                        username_textbox2.Clear();
                        password_textbox2.Clear();
                        username_textbox2.Focus();

                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {


                }

            }

            else 
            {

                try
                {
                    string query = "SELECT * FROM SocietyMember WHERE username = '" + username_textbox2.Text + "' AND password = '" + password_textbox2.Text + "'";


                    SqlDataAdapter sda = new SqlDataAdapter(query, con);

                    DataTable dtable = new DataTable();
                    sda.Fill(dtable);

                    if (dtable.Rows.Count > 0)
                    {
                        string designation = dtable.Rows[0]["designation"].ToString();

                        username = username_textbox2.Text;
                        password = password_textbox2.Text;

                       
                        CurrentUser.Username = username_textbox2.Text; 
                        MessageBox.Show("Welcome Society Member");
                        SocietyMemberForm smform = new SocietyMemberForm();
                        smform.Show();

                        this.Hide();
                      



                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password.");
                        username_textbox2.Clear();
                        password_textbox2.Clear();
                        username_textbox2.Focus();

                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {


                }

            }
          

            }

        private void username_textbox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }


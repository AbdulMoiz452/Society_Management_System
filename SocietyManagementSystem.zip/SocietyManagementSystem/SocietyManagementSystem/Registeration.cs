﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SocietyManagementSystem
{
    public partial class Registeration : Form
    {
        public Registeration()
        {
            InitializeComponent();
        }

        private void Registeration_Load(object sender, EventArgs e)
        {

        }

        private void LogIn_button_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Visible = true;
            this.Visible = false;
        }

        private void Register_button_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True");



            try
            {
                con.Open();
                DateTime currentDateTime = DateTime.Now;

                // Step 1: Insert data into register2 table
                SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[register2]
           (date)
           VALUES
           (@Date); 
           SELECT SCOPE_IDENTITY()", con);

               

                cmd.Parameters.AddWithValue("@Date", currentDateTime);
                int register2PrimaryKey = Convert.ToInt32(cmd.ExecuteScalar());
               
             
                if (Designation_comboBox1.SelectedItem == "Administrator")
                {
                    SqlCommand cmd2 = new SqlCommand(@"INSERT INTO [dbo].[Administrator]
                    ([register2_id]  -- Assuming this is the foreign key referencing the register1 table
                    ,[firstname]
                    ,[lastname]
                    ,[address]
                    ,[email]
                    ,[gender]
                    ,[designation]
                    ,[phone]
                    ,[username]
                    ,[password])
                    VALUES
                    (@Register1ID, @FirstName, @LastName, @Address, @Email, @Gender, @Designation, @Phone, @Username, @Password)", con);

                   
                    cmd2.Parameters.AddWithValue("@Register1ID", register2PrimaryKey); // Use the retrieved primary key
                    cmd2.Parameters.AddWithValue("@FirstName", FName_textbox.Text);
                    cmd2.Parameters.AddWithValue("@LastName", LName_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Address", Address_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Email", Email_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Gender", Gender_ComboBox.SelectedItem.ToString());
                    cmd2.Parameters.AddWithValue("@Designation", Designation_comboBox1.SelectedItem.ToString());
                    cmd2.Parameters.AddWithValue("@Phone", Phone_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Username", Username_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Password", Password_textbox.Text);

                    cmd2.ExecuteNonQuery();
                }
                else if (Designation_comboBox1.SelectedItem == "SocietyLead")
                {
                    SqlCommand cmd2 = new SqlCommand(@"INSERT INTO [dbo].[SocietyLead]
                    ([register2_id]  -- Assuming this is the foreign key referencing the register1 table
                    ,[firstname]
                    ,[lastname]
                    ,[address]
                    ,[email]
                    ,[gender]
                    ,[designation]
                    ,[phone]
                    ,[username]
                    ,[password])
                    VALUES
                    (@Register1ID, @FirstName, @LastName, @Address, @Email, @Gender, @Designation, @Phone, @Username, @Password)", con);

                    // Add parameters with actual values
                    cmd2.Parameters.AddWithValue("@Register1ID", register2PrimaryKey); // Use the retrieved primary key
                    cmd2.Parameters.AddWithValue("@FirstName", FName_textbox.Text);
                    cmd2.Parameters.AddWithValue("@LastName", LName_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Address", Address_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Email", Email_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Gender", Gender_ComboBox.SelectedItem.ToString());
                    cmd2.Parameters.AddWithValue("@Designation", Designation_comboBox1.SelectedItem.ToString());
                    cmd2.Parameters.AddWithValue("@Phone", Phone_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Username", Username_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Password", Password_textbox.Text);

                    cmd2.ExecuteNonQuery();
                }
                else
                {
                    SqlCommand cmd2 = new SqlCommand(@"INSERT INTO [dbo].[SocietyMember]
                    ([register2_id] 
                    ,[firstname]
                    ,[lastname]
                    ,[address]
                    ,[email]
                    ,[gender]
                    ,[designation]
                    ,[phone]
                    ,[username]
                    ,[password])
                    VALUES
                    (@Register1ID, @FirstName, @LastName, @Address, @Email, @Gender, @Designation, @Phone, @Username, @Password)", con);

                    
                    cmd2.Parameters.AddWithValue("@Register1ID", register2PrimaryKey); 
                    cmd2.Parameters.AddWithValue("@FirstName", FName_textbox.Text);
                    cmd2.Parameters.AddWithValue("@LastName", LName_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Address", Address_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Email", Email_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Gender", Gender_ComboBox.SelectedItem.ToString());
                    cmd2.Parameters.AddWithValue("@Designation", Designation_comboBox1.SelectedItem.ToString());
                    cmd2.Parameters.AddWithValue("@Phone", Phone_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Username", Username_textbox.Text);
                    cmd2.Parameters.AddWithValue("@Password", Password_textbox.Text);

                    cmd2.ExecuteNonQuery();
                }
               

                MessageBox.Show("Register Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SocietyManagementSystem
{
    public partial class MembersRegisterByAdmin : Form
    {
        public MembersRegisterByAdmin()
        {
            InitializeComponent();
            PopulateComboBox1();
            PopulateComboBox2();
        }



        private void PopulateComboBox1()
        {
            string connectionString = "Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True";
            string query = "SELECT societyName FROM SocietyCreate";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                comboBox1.Items.Add(reader["societyName"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void PopulateComboBox2()
        {
            string connectionString = "Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True";
            string query = "SELECT username FROM SocietyLead UNION SELECT username FROM SocietyMember;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                comboBox2.Items.Add(reader["username"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SocietyManageAdmin_Load(object sender, EventArgs e)
        {

        }



        private int FindMemID(SqlConnection connection, string memName)
        {
            string query = "SELECT id FROM SocietyLead WHERE username = @Username " +
                           "UNION " +
                           "SELECT id FROM SocietyMember WHERE username = @Username";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@Username", comboBox2.SelectedItem.ToString());

                object result = cmd.ExecuteScalar();

                if (result != null)
                {
                    return Convert.ToInt32(result);
                }

                throw new Exception("Member ID not found for the selected Society Member Name");
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {

            string ConnectionString = "Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();

                    string insertQuery = @"
                INSERT INTO RegisterMembersAdmin 
                (member_id,SocietyName, memberName, designation, department) 
                VALUES 
                (@Member_ID, @societyname, @MemberName, @Designation, @Department)
            ";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        string socName = comboBox1.SelectedItem.ToString();
                        string memName = comboBox2.SelectedItem.ToString();
                        string desg = comboBox3.SelectedItem.ToString();
                        string dep = comboBox4.SelectedItem.ToString();
                        int memId = FindMemID(connection, memName);

                        cmd.Parameters.AddWithValue("@Member_ID", memId);
                        cmd.Parameters.AddWithValue("@societyname", socName);
                        cmd.Parameters.AddWithValue("@MemberName", memName);
                        cmd.Parameters.AddWithValue("@Designation", desg);
                        cmd.Parameters.AddWithValue("@Department", dep);


                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data inserted successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to insert data.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

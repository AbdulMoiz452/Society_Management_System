﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SocietyManagementSystem
{
    public partial class MembersManageByLead : Form
    {
        public MembersManageByLead()
        {
            InitializeComponent();
            PopulateComboBox1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                string selectedUsername = comboBox1.SelectedItem.ToString();
                EditMemberByLead1 editmem1 = new EditMemberByLead1(selectedUsername);
                editmem1.Visible = true;
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("Please select a username from the combo box.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PopulateComboBox1()
        {
            string connectionString = "Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True";
            
            string query = "SELECT memberName FROM RegisterMembersAdmin UNION SELECT memberName FROM RegisterMembersByLead;";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                comboBox1.Items.Add(reader["memberName"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void MembersManageByLead_Load(object sender, EventArgs e)
        {

        }
    }
}

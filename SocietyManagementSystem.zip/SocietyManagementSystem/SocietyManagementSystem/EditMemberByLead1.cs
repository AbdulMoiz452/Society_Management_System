﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace SocietyManagementSystem
{
    public partial class EditMemberByLead1 : Form
    {
        private string selectedUsername;
        SqlDataAdapter sda;
        SqlCommandBuilder scb;
        DataTable dt;

        public EditMemberByLead1(string username)
        {
            
            InitializeComponent();
            selectedUsername = username;
            DisplayUserData();
        }


       


        private void DisplayUserData()
        {
           

            if (!string.IsNullOrEmpty(selectedUsername))
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True");


                sda = new SqlDataAdapter($"select * from SocietyMember where username = '{selectedUsername}'", con);

                dt = new DataTable();
                sda.Fill(dt);

                dataGridView1.DataSource = dt;

                dataGridView1.ReadOnly = false;
               
                dataGridView1.AllowUserToAddRows = true;
            }
            else
            {
                MessageBox.Show("Unable to determine the current user's identity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void EditMemberByLead1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                scb = new SqlCommandBuilder(sda);
                sda.Update(dt);
                MessageBox.Show("Changes saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}


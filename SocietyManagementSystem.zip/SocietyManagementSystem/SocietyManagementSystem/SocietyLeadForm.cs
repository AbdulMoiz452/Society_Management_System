﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SocietyManagementSystem
{
    public partial class SocietyLeadForm : Form
    {
        SqlDataAdapter sda;
        SqlCommandBuilder scb;
        DataTable dt;
        public SocietyLeadForm()
        {
            InitializeComponent();
            PopulateData();
        }

        private void registerMemberButton_Click(object sender, EventArgs e)
        {
            RegisterMemberLead registerMemberLead = new RegisterMemberLead();
            registerMemberLead.Visible = true;
            this.Visible = false;
              
        }



        public void PopulateData()
        {

            string currentUser = CurrentUser.Username;

            if (!string.IsNullOrEmpty(currentUser))
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True");


                sda = new SqlDataAdapter($"select * from SocietyLead where username = '{currentUser}'", con);

                dt = new DataTable();
                sda.Fill(dt);

                dataGridView1.DataSource = dt;

                dataGridView1.ReadOnly = false;
               
                dataGridView1.AllowUserToAddRows = true;
            }
            else
            {
                MessageBox.Show("Unable to determine the current user's identity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                scb = new SqlCommandBuilder(sda);
                sda.Update(dt);
                MessageBox.Show("Changes saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MembersManageByLead membersmanage = new MembersManageByLead();
            membersmanage.Visible = true;
            this.Visible = false;
        }

        private void SocietyLeadForm_Load(object sender, EventArgs e)
        {

        }
    }
}

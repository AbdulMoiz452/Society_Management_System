﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SocietyManagementSystem
{
    public partial class SocietyCreation : Form
    {
        public SocietyCreation()
        {
            InitializeComponent();
            PopulateComboBox();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void PopulateComboBox()
        {
            string connectionString = "Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True";
            string query = "SELECT username FROM SocietyLead";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                comboBox1.Items.Add(reader["username"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
               
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void SocietyCreation_Load(object sender, EventArgs e)
        {

        }


        private int FindSLID(SqlConnection connection, string taName)
        {
            string query = "SELECT id FROM SocietyLead WHERE username = '" + comboBox1.SelectedItem.ToString() + "'";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {


                object result = cmd.ExecuteScalar();

                if (result != null)
                {
                    return Convert.ToInt32(result);
                }

               
                throw new Exception("SLID not found for the selected Society Lead Name");
            }
        }



        private void CreateSociety_Button_Click(object sender, EventArgs e)
        {


            string ConnectionString = "Data Source=DESKTOP-7A4Q7V9\\SQLEXPRESS;Initial Catalog=SE_project;Integrated Security=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();

                    string insertQuery = @"
                INSERT INTO SocietyCreate 
                (SocietyLead,SocietyName, SocietyMission) 
                VALUES 
                (@societylead, @societyname, @societymission)
            ";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        string slName = comboBox1.SelectedItem.ToString();
                        int slId = FindSLID(connection, slName);

                        cmd.Parameters.AddWithValue("@societyname", textBox1.Text);
                        cmd.Parameters.AddWithValue("@societymission", richTextBox1.Text);
                        cmd.Parameters.AddWithValue("@societylead", slId);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data inserted successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to insert data.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
